document.addEventListener('DOMContentLoaded', () => {
    fetchReportes();
    document.getElementById('search-button').addEventListener('click', () => {
        const searchTerm = document.getElementById('search-input').value.trim();
        fetchReportes(searchTerm);
    });

    document.getElementById('color-filter').addEventListener('change', () => {
        const selectedColor = document.getElementById('color-filter').value;
        fetchReportes('', selectedColor);
    });
});
function fetchReportes(searchTerm = '', colorFilter = '') {
    let url = '/api/reportes';
    if (searchTerm) {
        url += `?search=${encodeURIComponent(searchTerm)}`;
    }

    if (colorFilter) {
        url += (searchTerm ? '&' : '?') + `color=${encodeURIComponent(colorFilter)}`;
    }

    fetch(url)
        .then(response => response.json())
        .then(data => displayReportes(data, colorFilter))
        .catch(error => console.error('Error:', error));
}

function displayReportes(reportes, colorFilter) {
    const container = document.getElementById('reportes-container');

    container.innerHTML = '';

    if (colorFilter === '') {
        reportes.sort((a, b) => new Date(b.reporte_fecha) - new Date(a.reporte_fecha));
        
        reportes.forEach(reporte => {
            const row = document.createElement('tr');
            
            const banderaCell = document.createElement('td');
            const banderaDiv = document.createElement('div');
            banderaDiv.classList.add('reporte-bandera');
            const color = getColorByTraffic(reporte.reporte_trafico);
            banderaDiv.style.backgroundColor = color;
            banderaCell.appendChild(banderaDiv);
            
            row.innerHTML = `
                ${banderaCell.outerHTML}
                <td>${reporte.reporte_radiobase}</td>
                <td>${reporte.reporte_trafico}</td>
                <td>${reporte.reporte_fecha}</td>
                <td>${reporte.reporte_activo}</td>
            `;

            container.appendChild(row);
        });
    } else {
        const colorContainers = {};
        const section = document.createElement('tbody');
        section.className = 'report-section';
        section.style.backgroundColor = colorFilter;
        section.style.padding = '10px';
        section.style.marginBottom = '10px';
        section.style.borderRadius = '4px';
        section.style.color = '#fff';
        section.innerHTML = `<tr><th colspan="5">Color: ${colorFilter}</th></tr>`;
        container.appendChild(section);
        colorContainers[colorFilter] = section;
        reportes.forEach(reporte => {
            const color = getColorByTraffic(reporte.reporte_trafico);
            if (color === colorFilter) {
                const row = document.createElement('tr');
                
                const banderaCell = document.createElement('td');
                const banderaDiv = document.createElement('div');
                banderaDiv.classList.add('reporte-bandera');
                banderaDiv.style.backgroundColor = color;
                banderaCell.appendChild(banderaDiv);
                
                row.innerHTML = `
                    ${banderaCell.outerHTML}
                    <td>${reporte.reporte_radiobase}</td>
                    <td>${reporte.reporte_trafico}</td>
                    <td>${reporte.reporte_fecha}</td>
                    <td>${reporte.reporte_activo}</td>
                `;

                section.appendChild(row);
            }
        });
    }
}
function getColorByTraffic(trafico) {
    if (trafico === null || trafico === undefined) {
        return 'gray'; 
    } else if (trafico <= 15) {
        return 'red'; 
    } else if (trafico > 15 && trafico <= 40) {
        return 'orange';
    } else if (trafico > 40 && trafico <= 90) {
        return 'yellow'; 
    } else if (trafico > 90) {
        return 'green'; 
    } else {
        return 'gray'; 
    }
}
