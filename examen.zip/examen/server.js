const express = require('express');
const mysql = require('mysql');
const app = express();
const port = 3000;

// Configuración de la conexión a la base de datos
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'examen_uno'
});

db.connect((err) => {
  if (err) throw err;
  console.log('Conectado a la base de datos MySQL');
});
app.use(express.static('public'));
app.get('/api/reportes', (req, res) => {
  const fecha = '2024-07-24'; // Puedes ajustar esta fecha según sea necesario
  const searchTerm = req.query.search || '';
  
  let sql = 'SELECT * FROM tbl_ope_reporte WHERE reporte_fecha >= ?';
  let queryParams = [fecha];
  if (searchTerm) {
    sql += ' AND reporte_radiobase LIKE ?';
    queryParams.push('%' + searchTerm + '%');
  }

  sql += ' ORDER BY reporte_fecha DESC';

  db.query(sql, queryParams, (err, result) => {
    if (err) throw err;
    res.json(result);
  });
});

app.listen(port, () => {
  console.log(`Servidor corriendo en http://localhost:${port}`);
});
